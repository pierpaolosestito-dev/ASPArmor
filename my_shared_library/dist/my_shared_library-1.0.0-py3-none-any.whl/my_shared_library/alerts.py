def WARNING_MESSAGE(msg):
    return f"[bold yellow]WARNING: {msg}[/bold yellow]"
def ERROR_MESSAGE(msg):
    return f"[bold red]ERROR: {msg}[/bold red]"
def SUCCESS_MESSAGE(msg):
    return f"[bold green]SUCCESS: {msg}[/bold green]"
def INFO_MESSAGE(msg):
    return f"[bold blue]INFO: {msg}[/bold blue]"