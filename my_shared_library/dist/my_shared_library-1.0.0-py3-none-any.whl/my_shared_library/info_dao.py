from .database_connection import DatabaseConnection


class Info:
    def __init__(self,username,executable,profile):
        self.username = username
        self.executable = executable
        self.profile = profile

    def __str__(self):
        return f"{self.username}::{self.executable}::{self.profile}"

class InfoDAO:
    def __init__(self,cursor):
        self.cursor = cursor

    def create(self, info : Info):
        query = """INSERT INTO info (username,executable,profile)
                    VALUES (?,?,?);"""
        self.cursor.execute(query,(info.username,info.executable,info.profile))
        return self.cursor.lastrowid

    def already_exists(self, info : Info):
        query = """SELECT 1 from info
                    WHERE username=? AND executable = ? AND profile = ?"""
        self.cursor.execute(query,(info.username,info.executable,info.profile))
        return self.cursor.fetchone() is not None

    def read_all(self):
        query = "SELECT * FROM info;"
        self.cursor.execute(query)
        return self.cursor.fetchall()

    def delete(self,info : Info):
        query = "DELETE FROM info WHERE username = ? and profile = ?;"
        self.cursor.execute(query,(info.username,info.profile))
        return self.cursor.rowcount > 0

    def delete_all(self):
        query = "DELETE from info;"
        self.cursor.execute(query)
        self.cursor.connection.commit()
        return self.cursor.rowcount

    def get_profiles_by_username_by_executable(self,username,executable):
        query = """SELECT profile FROM info WHERE username = ? AND executable = ?;"""
        self.cursor.execute(query,(username,executable,))
        return [row[0] for row in self.cursor.fetchall()]
    
    def get_profiles_by_username(self,username):
        query = """SELECT profile FROM info WHERE username = ?;"""
        self.cursor.execute(query,(username,executable,))
        return [row[0] for row in self.cursor.fetchall()]

        


